#! /bin/bash
java -jar neural.jar $1 $2 $3 $4
